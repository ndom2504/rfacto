#!/bin/sh
echo "=== DEMARRAGE RFACTO BACKEND ==="

# 1. Correction des migrations (rapide si pas de probleme)
echo "Etape 1: Correction migrations..."
node scripts/fixAzureMigration.js
if [ $? -ne 0 ]; then
    echo "WARN: Fix migration a echoue, continuer quand meme"
fi

# 2. Appliquer les migrations
echo "Etape 2: Migrations Prisma..."
npx prisma migrate deploy
if [ $? -ne 0 ]; then
    echo "WARN: Migrations ont echoue, continuer quand meme"
fi

# 3. Demarrer l'application
echo "Etape 3: Demarrage serveur..."
exec node src/server.cjs
